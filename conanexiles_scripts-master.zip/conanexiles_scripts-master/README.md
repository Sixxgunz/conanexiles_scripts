# conanexiles_scripts
This is a collection of gathered sql scripts from the conan exiles server owner community and a few I have modified or created myself.  This collection includes a complete custom item cross referencing table which can be used for many reasons and many custom database views to make your life as a server owner and the lives of your admins much less stressful.
